import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("shadow.db");

// تهيئة قاعدة البيانات مع دعم السيناريوهات والتدريب المتكرر
db.exec(`
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    training_count INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS scenarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER,
    run_number INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_id INTEGER,
    type TEXT, -- click, type, scroll, open_app
    target_id TEXT, -- Resource ID or Text
    content TEXT,
    x INTEGER,
    y INTEGER,
    delay INTEGER,
    FOREIGN KEY(scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE
  );
`);

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  app.get("/api/tasks", (req, res) => {
    const tasks = db.prepare("SELECT * FROM tasks ORDER BY created_at DESC").all();
    res.json(tasks);
  });

  app.post("/api/tasks", (req, res) => {
    const { name, description, steps } = req.body;
    
    // 1. Create Task
    const taskInsert = db.prepare("INSERT INTO tasks (name, description) VALUES (?, ?)").run(name, description);
    const taskId = taskInsert.lastInsertRowid;

    // 2. Create Initial Scenario
    const scenarioInsert = db.prepare("INSERT INTO scenarios (task_id, run_number) VALUES (?, ?)").run(taskId, 1);
    const scenarioId = scenarioInsert.lastInsertRowid;

    // 3. Insert Steps
    const stepInsert = db.prepare("INSERT INTO steps (scenario_id, type, target_id, content, x, y, delay) VALUES (?, ?, ?, ?, ?, ?, ?)");
    for (const step of steps) {
      stepInsert.run(scenarioId, step.type, step.target_id, step.content, step.x, step.y, step.delay || 500);
    }

    res.json({ id: taskId, success: true });
  });

  app.get("/api/tasks/:id/best-scenario", (req, res) => {
    // في التطبيق الحقيقي، هنا يتم تحليل السيناريوهات واختيار الأفضل
    const scenario = db.prepare("SELECT id FROM scenarios WHERE task_id = ? ORDER BY id DESC LIMIT 1").get(req.params.id);
    if (!scenario) return res.status(404).json({ error: "No scenario found" });
    
    const steps = db.prepare("SELECT * FROM steps WHERE scenario_id = ? ORDER BY id ASC").all(scenario.id);
    res.json(steps);
  });

  app.delete("/api/tasks/:id", (req, res) => {
    db.prepare("DELETE FROM tasks WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Shadow Server running on http://localhost:${PORT}`);
  });
}

startServer();
