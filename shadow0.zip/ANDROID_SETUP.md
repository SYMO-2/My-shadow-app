# دليل تحويل التطبيق إلى APK حقيقي (Android APK Guide)

لتحويل هذا الكود إلى تطبيق أندرويد حقيقي يتحكم في الشاشة فعلياً، اتبع الخطوات التالية:

## 1. إعداد بيئة Capacitor
قم بتشغيل الأوامر التالية في مجلد المشروع:
```bash
npm run build
npx cap add android
npx cap sync
```

## 2. إعداد خدمة الوصول (Accessibility Service) في أندرويد
هذا هو الجزء الأهم. يجب إضافة كود Java التالي في مشروع الأندرويد (داخل Android Studio) لتمكين التحكم الفعلي.

### أ. إنشاء ملف `AutoExecutorService.java`
في مسار `android/app/src/main/java/com/autoexecutor/app/AutoExecutorService.java`:

```java
package com.autoexecutor.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class AutoExecutorService extends AccessibilityService {
    private static AutoExecutorService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    public static void performClick(int x, int y) {
        if (instance == null) return;
        
        Path clickPath = new Path();
        clickPath.moveTo(x, y);
        GestureDescription.StrokeDescription clickStroke = new GestureDescription.StrokeDescription(clickPath, 0, 100);
        GestureDescription.Builder clickBuilder = new GestureDescription.Builder();
        clickBuilder.addStroke(clickStroke);
        instance.dispatchGesture(clickBuilder.build(), null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}
}
```

### ب. تعديل ملف `AndroidManifest.xml`
أضف الكود التالي داخل وسم `<application>`:

```xml
<service
    android:name=".AutoExecutorService"
    android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
    android:exported="true">
    <intent-filter>
        <action android:name="android.accessibilityservice.AccessibilityService" />
    </intent-filter>
    <meta-data
        android:name="android.accessibilityservice"
        android:resource="@xml/accessibility_service_config" />
</service>
```

### ج. إنشاء ملف الإعدادات `res/xml/accessibility_service_config.xml`
```xml
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault"
    android:canPerformGestures="true"
    android:canRetrieveWindowContent="true"
    android:notificationTimeout="100" />
```

## 3. بناء الـ APK
افتح مجلد `android` باستخدام **Android Studio** واضغط على **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---
**ملاحظة:** بمجرد تثبيت الـ APK، يجب الذهاب إلى إعدادات الموبايل > إمكانية الوصول (Accessibility) وتفعيل "AutoExecutor" ليعمل التطبيق فعلياً.
