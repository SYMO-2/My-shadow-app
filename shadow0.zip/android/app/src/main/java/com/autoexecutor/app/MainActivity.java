package com.autoexecutor.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
