/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  PlusCircle, 
  List, 
  Settings as SettingsIcon, 
  Play, 
  Trash2, 
  Edit3, 
  RefreshCw,
  Mic,
  StopCircle,
  CheckCircle,
  AlertTriangle,
  Zap,
  ChevronDown,
  Minimize2,
  Smartphone,
  Ghost,
  X,
  Cpu,
  Globe,
  Shield,
  Layers,
  Activity,
  Info,
  Circle,
  Square,
  BoxSelect,
  Palette,
  Clock
} from 'lucide-react';
import { androidBridge } from './services/AndroidBridge';
import { motion, AnimatePresence, useMotionValue, useTransform, animate } from 'motion/react';
import { Capacitor } from '@capacitor/core';

// Types
export type ActionType = 'click' | 'long_press' | 'swipe' | 'input' | 'open_app' | 'wait';

export interface AutomationAction {
  id: string;
  type: ActionType;
  timestamp: number;
  delay: number;
  x?: number;
  y?: number;
  endX?: number;
  endY?: number;
  content?: string;
  packageName?: string;
  retryCount?: number;
}

export interface AutomationTask {
  id: string;
  name: string;
  description: string;
  actions: AutomationAction[];
  createdAt: number;
  lastExecuted?: number;
  status: 'idle' | 'running' | 'failed' | 'completed';
  progress: number;
  schedule?: {
    enabled: boolean;
    intervalMs: number;
  };
}

// Loading Screen Component (Moved outside to prevent re-renders restarting animations)
const LoadingScreen = ({ language, loadingStatus }: { language: string, loadingStatus: string }) => {
  const progress = useMotionValue(0);
  const [percent, setPercent] = useState(0);
  
  useEffect(() => {
    const controls = animate(progress, 100, {
      duration: 4,
      ease: "circOut",
      onUpdate: (v) => setPercent(Math.round(v))
    });
    return controls.stop;
  }, [progress]);

  const width = useTransform(progress, [0, 100], ["0%", "100%"]);

  return (
    <div className="fixed inset-0 bg-[#000000] z-[500] flex flex-col items-center justify-center p-12 overflow-hidden">
      {/* Fluid Organic Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          animate={{ 
            scale: [1, 1.5, 1],
            rotate: [0, 180, 360],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-[-20%] left-[-20%] w-[140%] h-[140%] bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.15)_0%,transparent_70%)] blur-[100px]"
        />
        
        {/* Animated Neural Connections (Fluid Lines) */}
        <svg className="absolute inset-0 w-full h-full opacity-20">
          <motion.path
            d="M -100 100 Q 200 300 500 100 T 1100 300"
            fill="none"
            stroke="rgba(129,140,248,0.3)"
            strokeWidth="0.5"
            initial={{ pathLength: 0, pathOffset: 0 }}
            animate={{ pathLength: [0, 1, 0], pathOffset: [0, 0, 1] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.path
            d="M -100 500 Q 300 200 700 500 T 1200 200"
            fill="none"
            stroke="rgba(168,85,247,0.2)"
            strokeWidth="0.5"
            initial={{ pathLength: 0, pathOffset: 0 }}
            animate={{ pathLength: [0, 1, 0], pathOffset: [0, 0, 1] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          />
        </svg>
      </div>

      <div className="relative z-10 w-full max-w-md flex flex-col items-center">
        {/* The "Shadow" Mimicry Animation */}
        <div className="relative mb-20 w-48 h-48 flex items-center justify-center">
          {/* Pulsing Aura */}
          <motion.div 
            animate={{ 
              scale: [1, 1.4, 1],
              opacity: [0.3, 0.6, 0.3]
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="absolute inset-0 bg-indigo-500/10 rounded-full blur-3xl"
          />
          
          {/* Floating Ghost Icon with Fluid Motion */}
          <motion.div 
            animate={{ 
              y: [-10, 10, -10],
              rotate: [-5, 5, -5]
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="relative z-10"
          >
            <div className="relative p-8 rounded-[3rem] bg-white/[0.02] border border-white/5 backdrop-blur-2xl shadow-2xl">
              <Ghost className="text-white w-16 h-16 drop-shadow-[0_0_20px_rgba(129,140,248,0.6)]" />
              
              {/* Ghostly Trails (The "Shadow" working) */}
              <AnimatePresence>
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 1 }}
                    animate={{ 
                      opacity: [0, 0.5, 0],
                      scale: [1, 1.5],
                      x: [0, (i - 1) * 30],
                      y: [0, (i - 1) * 30]
                    }}
                    transition={{ 
                      duration: 2, 
                      repeat: Infinity, 
                      delay: i * 0.6,
                      ease: "easeOut"
                    }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    <Ghost className="text-indigo-400/20 w-16 h-16" />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
        
        {/* Narrative Text */}
        <div className="text-center space-y-10 w-full">
          <div className="space-y-3">
            <h1 className="text-5xl font-extralight tracking-tight text-white">
              Shadow
            </h1>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="inline-block px-4 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20"
            >
              <span className="text-[9px] text-indigo-400 font-bold uppercase tracking-[0.3em]">
                {language === 'ar' ? 'ظل يستعد للعمل' : 'Shadow is preparing'}
              </span>
            </motion.div>
          </div>

          {/* Fluid Progress Bar */}
          <div className="max-w-[240px] mx-auto space-y-4">
            <div className="flex justify-between items-center px-1">
              <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">
                {loadingStatus}
              </span>
              <span className="text-[10px] font-mono text-indigo-400">
                {percent}%
              </span>
            </div>
            <div className="h-[2px] w-full bg-white/5 relative rounded-full overflow-hidden">
              <motion.div 
                style={{ width }}
                className="h-full bg-gradient-to-r from-indigo-600 to-indigo-400 shadow-[0_0_20px_rgba(129,140,248,0.8)]"
              />
              {/* Liquid highlight effect */}
              <motion.div 
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 w-1/3 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
              />
            </div>
          </div>

          <p className="text-[10px] text-white/20 font-light italic max-w-[200px] mx-auto leading-relaxed">
            {language === 'ar' 
              ? 'سأقوم بتعلم حركاتك وتنفيذها بدقة تامة...' 
              : 'I will learn your movements and execute them with precision...'}
          </p>
        </div>
      </div>

      {/* Subtle Floating Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 1000, 
              y: Math.random() * 800,
              opacity: 0 
            }}
            animate={{ 
              y: [null, -100],
              opacity: [0, 0.3, 0]
            }}
            transition={{ 
              duration: 5 + Math.random() * 5, 
              repeat: Infinity,
              delay: Math.random() * 5
            }}
            className="absolute w-1 h-1 bg-white/20 rounded-full blur-[1px]"
          />
        ))}
      </div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'training' | 'tasks' | 'settings'>('tasks');
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [tasks, setTasks] = useState<AutomationTask[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [currentRecording, setCurrentRecording] = useState<AutomationAction[]>([]);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [newTask, setNewTask] = useState({ name: '', description: '' });
  const [executingTaskId, setExecutingTaskId] = useState<string | null>(null);
  const [executionProgress, setExecutionProgress] = useState(0);
  const [lastActionTime, setLastActionTime] = useState<number>(0);
  const [isSaving, setIsSaving] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingStatus, setLoadingStatus] = useState('');
  const [permissions, setPermissions] = useState({
    accessibility: false,
    overlay: true,
    foreground: true
  });

  useEffect(() => {
    const initApp = async () => {
      // Loading Sequence Simulation
      const statuses = language === 'ar' ? [
        "جاري فحص النواة...",
        "تحميل محرك الوصول...",
        "مزامنة قاعدة بيانات المهام...",
        "تجهيز واجهة الظل...",
        "النظام جاهز"
      ] : [
        "Checking Core...",
        "Loading Accessibility Engine...",
        "Syncing Task Database...",
        "Preparing Shadow Interface...",
        "System Ready"
      ];

      // Smooth continuous progress logic
      const totalDuration = 4000; // 4 seconds total
      const startTime = Date.now();
      
      const updateProgress = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min((elapsed / totalDuration) * 100, 100);
        setLoadingProgress(progress);
        
        // Update status text based on progress
        const statusIdx = Math.min(Math.floor((progress / 100) * statuses.length), statuses.length - 1);
        setLoadingStatus(statuses[statusIdx]);

        if (progress < 100) {
          requestAnimationFrame(updateProgress);
        }
      };

      requestAnimationFrame(updateProgress);
      
      // Wait for the duration to finish
      await new Promise(resolve => setTimeout(resolve, totalDuration + 500));

      const status = await androidBridge.checkPermissions();
      setPermissions({
        accessibility: status.accessibility,
        overlay: status.overlay,
        foreground: status.batteryOptimization
      });
      
      setIsLoading(false);
      
      // If critical permission is missing, show setup
      if (!status.accessibility) {
        setShowSetup(true);
      }
    };
    initApp();
  }, [language]);

  const togglePermission = async (key: keyof typeof permissions) => {
    if (key === 'accessibility') {
      await androidBridge.requestAccessibilityPermission();
    } else if (key === 'overlay') {
      await androidBridge.requestOverlayPermission();
    }
    
    // تحديث الحالة محلياً (في التطبيق الحقيقي سيتم التحديث بعد العودة من الإعدادات)
    setPermissions(prev => ({ ...prev, [key]: !prev[key] }));
  };
  
  // New States for Simulation
  const [isMinimized, setIsMinimized] = useState(false);
  const [showOverlayMenu, setShowOverlayMenu] = useState(false);

  // Overlay Customization States
  const [overlayConfig, setOverlayConfig] = useState({
    size: 64,
    opacity: 1,
    color: '#818cf8', // indigo-400
    shape: 'circle' as 'circle' | 'square' | 'rounded'
  });

  const [buttonSide, setButtonSide] = useState<'left' | 'right'>('right');
  const [isDocked, setIsDocked] = useState(false);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const dockTimerRef = useRef<NodeJS.Timeout | null>(null);
  const constraintsRef = useRef(null);

  const resetDockTimer = () => {
    if (dockTimerRef.current) clearTimeout(dockTimerRef.current);
    setIsDocked(false);
    dockTimerRef.current = setTimeout(() => {
      if (!showOverlayMenu && !isRecording) {
        setIsDocked(true);
      }
    }, 3000);
  };

  useEffect(() => {
    if (isDocked) {
      const currentX = x.get();
      const initialXFromLeft = window.innerWidth - 48 - overlayConfig.size;
      const absoluteX = initialXFromLeft + currentX;
      const screenWidth = window.innerWidth;
      
      let targetX = currentX;
      if (buttonSide === 'left') {
        // Dock to left: absolute position should be -size/2
        targetX = -overlayConfig.size / 2 - initialXFromLeft;
      } else {
        // Dock to right: absolute position should be screenWidth - size/2
        targetX = screenWidth - overlayConfig.size / 2 - initialXFromLeft;
      }
      
      animate(x, targetX, { type: 'spring', stiffness: 300, damping: 30 });
    }
  }, [isDocked, buttonSide, overlayConfig.size]);

  useEffect(() => {
    if (isMinimized) {
      resetDockTimer();
    }
    return () => {
      if (dockTimerRef.current) clearTimeout(dockTimerRef.current);
    };
  }, [isMinimized, showOverlayMenu, isRecording]);

  const [constraints, setConstraints] = useState({ left: 0, right: 0, top: 0, bottom: 0 });

  useEffect(() => {
    const updateConstraints = () => {
      setConstraints({
        left: -(window.innerWidth - 48 - overlayConfig.size),
        right: 48,
        top: -(window.innerHeight - 160 - overlayConfig.size),
        bottom: 160
      });
    };
    updateConstraints();
    window.addEventListener('resize', updateConstraints);
    return () => window.removeEventListener('resize', updateConstraints);
  }, [overlayConfig.size]);

  // Simulated Background Scheduler
  useEffect(() => {
    const intervals: NodeJS.Timeout[] = [];
    
    tasks.forEach(task => {
      if (task.schedule?.enabled && task.status !== 'running') {
        const interval = setInterval(() => {
          console.log(`[Auto-Executor] Triggering scheduled task: ${task.name}`);
          executeTask(task.id);
        }, task.schedule.intervalMs);
        intervals.push(interval);
      }
    });

    return () => intervals.forEach(clearInterval);
  }, [tasks, executingTaskId]);
  useEffect(() => {
    // Initial tasks for demo
    setTasks([
      { 
        id: '1', 
        name: language === 'ar' ? "فتح واتساب وإرسال رسالة" : "Open WhatsApp & Send Message", 
        description: language === 'ar' ? "يقوم بفتح التطبيق واختيار جهة الاتصال وكتابة رسالة ترحيب" : "Opens app, selects contact and types greeting", 
        actions: [], 
        createdAt: Date.now(), 
        status: 'idle', 
        progress: 0 
      },
      { 
        id: '2', 
        name: language === 'ar' ? "تحديث بيانات المخزون" : "Update Inventory Data", 
        description: language === 'ar' ? "يدخل على تطبيق المتجر ويحدث الكميات المتوفرة" : "Enters store app and updates quantities", 
        actions: [], 
        createdAt: Date.now(), 
        status: 'idle', 
        progress: 0 
      }
    ]);
  }, [language]);

  // --- Auto-Executor Logic ---
  const startRecording = () => {
    setIsRecording(true);
    setCurrentRecording([]);
    setLastActionTime(Date.now());
    setShowOverlayMenu(false);
    if (!isMinimized) setIsMinimized(true);
  };

  const stopRecording = () => {
    setIsRecording(false);
    setShowSaveModal(true);
  };

  const recordAction = (action: Partial<AutomationAction>) => {
    if (!isRecording) return;
    const now = Date.now();
    const delay = now - lastActionTime;
    const newAction: AutomationAction = {
      id: Math.random().toString(36).substr(2, 9),
      type: action.type || 'click',
      timestamp: now,
      delay: delay,
      ...action
    };
    setCurrentRecording(prev => [...prev, newAction]);
    setLastActionTime(now);
  };

  const saveTask = async () => {
    if (!newTask.name || isSaving) return;
    setIsSaving(true);
    try {
      const taskData: AutomationTask = {
        id: Math.random().toString(36).substr(2, 9),
        name: newTask.name,
        description: newTask.description,
        actions: currentRecording,
        createdAt: Date.now(),
        status: 'idle',
        progress: 0
      };
      
      // Update local state (simulating persistence)
      setTasks(prev => [...prev, taskData]);
      
      setShowSaveModal(false);
      setNewTask({ name: '', description: '' });
      setCurrentRecording([]);
      setIsMinimized(false);
      setActiveTab('tasks');
    } catch (error) {
      console.error("Failed to save task:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const executeTask = async (taskId: string, maxRetries = 3) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task || executingTaskId) return;

    setExecutingTaskId(taskId);
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'running', progress: 0 } : t));

    let currentRetry = 0;
    let success = false;

    while (currentRetry <= maxRetries && !success) {
      try {
        for (let i = 0; i < task.actions.length; i++) {
          const action = task.actions[i];
          const progress = ((i + 1) / task.actions.length) * 100;
          setExecutionProgress(progress);
          setTasks(prev => prev.map(t => t.id === taskId ? { ...t, progress } : t));

          // Wait for the recorded delay (simulating real timing)
          await new Promise(resolve => setTimeout(resolve, action.delay || 500));

          // Simulation of action execution
          console.log(`[Auto-Executor] Executing ${action.type} at (${action.x}, ${action.y}) - Attempt ${currentRetry + 1}`);
          
          // تنفيذ النقرة الحقيقية إذا كان التطبيق يعمل على أندرويد
          if (action.type === 'click' && action.x !== undefined && action.y !== undefined) {
            await androidBridge.performNativeClick(action.x, action.y);
          }
          
          // Error handling simulation: 10% chance of failure to test retries
          if (Math.random() < 0.1) {
            throw new Error("Target app not responding or screen changed");
          }
        }
        success = true;
        setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'completed', lastExecuted: Date.now(), progress: 100 } : t));
      } catch (error) {
        currentRetry++;
        console.error(`[Auto-Executor] Attempt ${currentRetry} failed:`, error);
        
        if (currentRetry <= maxRetries) {
          console.log(`[Auto-Executor] Retrying in 2 seconds...`);
          await new Promise(resolve => setTimeout(resolve, 2000));
        } else {
          setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'failed' } : t));
        }
      }
    }

    setExecutingTaskId(null);
    setExecutionProgress(0);
  };

  // --- UI Components ---
  const RecordingOverlay = () => {
    const [touchStart, setTouchStart] = useState<{ x: number, y: number, time: number } | null>(null);
    const longPressTimer = useRef<NodeJS.Timeout | null>(null);

    if (!isRecording) return null;

    const handleMouseDown = (e: React.MouseEvent) => {
      const start = { x: e.clientX, y: e.clientY, time: Date.now() };
      setTouchStart(start);
      
      longPressTimer.current = setTimeout(() => {
        recordAction({
          type: 'long_press',
          x: start.x,
          y: start.y
        });
        setTouchStart(null);
      }, 600);
    };

    const handleMouseUp = (e: React.MouseEvent) => {
      if (longPressTimer.current) clearTimeout(longPressTimer.current);
      
      if (touchStart) {
        const endX = e.clientX;
        const endY = e.clientY;
        const distance = Math.sqrt(Math.pow(endX - touchStart.x, 2) + Math.pow(endY - touchStart.y, 2));
        
        if (distance > 30) {
          // It's a swipe
          recordAction({
            type: 'swipe',
            x: touchStart.x,
            y: touchStart.y,
            endX,
            endY
          });
        } else {
          // It's a simple click
          recordAction({
            type: 'click',
            x: touchStart.x,
            y: touchStart.y
          });
        }
      }
      setTouchStart(null);
    };

    return (
      <div 
        className="fixed inset-0 z-[99] bg-red-500/5 cursor-crosshair"
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
      >
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-600 text-white px-6 py-2 rounded-full font-bold animate-pulse flex items-center gap-2 shadow-xl border border-white/20">
          <div className="w-2 h-2 bg-white rounded-full" />
          {language === 'ar' ? 'جاري تسجيل الخطوات...' : 'Recording Actions...'}
          <span className="text-[8px] opacity-50 ml-2">({currentRecording.length})</span>
        </div>
        
        {/* Visual feedback for recording */}
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 bg-black/80 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-xl text-[8px] uppercase tracking-widest text-white/40">
          {language === 'ar' ? 'انقر للضغط، اضغط مطولاً، أو اسحب للتمرير' : 'Click to tap, Long press, or Swipe to scroll'}
        </div>
      </div>
    );
  };

  const editTask = (taskId: string, name: string, description: string) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, name, description } : t));
  };

  const scheduleTask = (taskId: string, intervalMs: number) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { 
      ...t, 
      schedule: { enabled: true, intervalMs } 
    } : t));
    
    // In a real app, this would set up a background alarm/job
    console.log(`[Auto-Executor] Scheduled task ${taskId} every ${intervalMs}ms`);
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const t = {
    ar: {
      shadow: "Shadow",
      ai: "ذكاء اصطناعي مستقل",
      train: "تدريب",
      sequences: "المهام",
      newSequence: "مهمة جديدة",
      observationDesc: "سيقوم Shadow بمراقبة تفاعلاتك عبر التطبيقات وتعلم أفضل مسار للتنفيذ.",
      initiate: "بدء التعلم",
      activeSequences: "المهام النشطة",
      emptyShadow: "الظل فارغ",
      executions: "مرات التنفيذ",
      recent: "الأخيرة",
      voiceInput: "إدخال صوتي",
      recording: "جاري تسجيل التسلسل",
      simulate: "محاكاة",
      finish: "إنهاء",
      settings: "إعدادات النظام",
      engine: "محرك الوصول",
      overlay: "واجهة العرض",
      background: "عملية الخلفية",
      active: "نشط",
      running: "يعمل",
      close: "إغلاق",
      captured: "تم التقاط التسلسل",
      label: "اسم المهمة",
      placeholder: "أدخل اسم المهمة...",
      discard: "تجاهل",
      confirm: "تأكيد",
      saving: "جاري الحفظ...",
      shadowing: "Shadow ينفذ الآن",
      language: "اللغة",
      switchLang: "English",
      systemStatus: "حالة النظام",
      version: "الإصدار",
      vNum: "v2.4.0-alpha",
      overlaySettings: "تخصيص الزر العائم",
      size: "الحجم",
      opacity: "الشفافية",
      color: "اللون",
      shape: "الشكل",
      circle: "دائري",
      square: "مربع",
      rounded: "منحني"
    },
    en: {
      shadow: "Shadow",
      ai: "Autonomous Intelligence",
      train: "Train",
      sequences: "Sequences",
      newSequence: "New Sequence",
      observationDesc: "Shadow will observe your interactions across applications and learn the optimal execution path.",
      initiate: "Initiate Observation",
      activeSequences: "Active Sequences",
      emptyShadow: "The shadow is empty",
      executions: "Executions",
      recent: "Recent",
      voiceInput: "Voice Input",
      recording: "Sequence Recording",
      simulate: "Simulate",
      finish: "Finish",
      settings: "System Settings",
      engine: "Accessibility Engine",
      overlay: "Overlay Interface",
      background: "Background Process",
      active: "Active",
      running: "Running",
      close: "Close",
      captured: "Sequence Captured",
      label: "Sequence Label",
      placeholder: "Enter sequence name...",
      discard: "Discard",
      confirm: "Confirm",
      saving: "Saving...",
      shadowing: "Shadowing Sequence",
      language: "Language",
      switchLang: "العربية",
      systemStatus: "System Status",
      version: "Version",
      vNum: "v2.4.0-alpha",
      overlaySettings: "Overlay Customization",
      size: "Size",
      opacity: "Opacity",
      color: "Color",
      shape: "Shape",
      circle: "Circle",
      square: "Square",
      rounded: "Rounded"
    }
  }[language];

  return (
    <div ref={constraintsRef} className={`min-h-screen bg-[#000000] text-[#FFFFFF] font-sans flex flex-col overflow-hidden selection:bg-indigo-500/30 ${language === 'ar' ? 'arabic-text' : ''}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div key="loader" exit={{ opacity: 0, scale: 1.1 }} transition={{ duration: 0.5 }}>
            <LoadingScreen language={language} loadingStatus={loadingStatus} />
          </motion.div>
        ) : (
          <motion.div 
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            <RecordingOverlay />
      
      {/* Simulation Background (Phone Home Screen) */}
      <AnimatePresence>
        {isMinimized && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-0 bg-cover bg-center"
            style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop")' }}
          >
            <div className="absolute inset-0 bg-black/70 backdrop-blur-[12px]"></div>
            
            {/* Mock App Icons */}
            <div className="grid grid-cols-4 gap-8 p-12 mt-32">
              {['WhatsApp', 'Facebook', 'Photos', 'Maps', 'Settings', 'Camera', 'Mail', 'Notes'].map(app => (
                <div key={app} className="flex flex-col items-center gap-3">
                  <div className="w-16 h-16 rounded-[2rem] bg-white/5 backdrop-blur-2xl border border-white/10 flex items-center justify-center shadow-2xl">
                    <Smartphone size={24} className="text-white/20" />
                  </div>
                  <span className="text-[10px] text-white/40 font-medium tracking-wider uppercase">{app}</span>
                </div>
              ))}
            </div>

            {/* Back to App Button (Simulated Home Button) */}
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2">
              <button 
                onClick={() => setIsMinimized(false)}
                className="w-24 h-1 bg-white/10 rounded-full hover:bg-white/30 transition-all duration-500"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main App UI */}
      <motion.div 
        animate={{ 
          y: isMinimized ? '100%' : '0%',
          opacity: isMinimized ? 0 : 1,
          scale: isMinimized ? 0.98 : 1
        }}
        transition={{ type: 'tween', duration: 0.3, ease: 'easeOut' }}
        className="flex-1 flex flex-col bg-[#000000] z-10 relative max-w-xl mx-auto w-full"
      >
        {/* Header */}
        <header className="px-8 py-10 flex items-center justify-between sticky top-0 bg-black/80 backdrop-blur-3xl z-50 border-b border-white/[0.03]">
          <div className="flex items-center gap-5">
            <div className="relative group">
              <div className="w-12 h-12 rounded-full bg-indigo-600/20 flex items-center justify-center relative z-10 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-transparent"></div>
                <Ghost className="text-indigo-400 w-6 h-6 relative z-20" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-black rounded-full border border-white/10 flex items-center justify-center z-30">
                <Zap size={8} className="text-indigo-400" />
              </div>
              <div className="absolute inset-0 bg-indigo-500/10 blur-xl rounded-full -z-10"></div>
            </div>
            <div>
              <h1 className="text-2xl font-light tracking-[0.1em] uppercase">{t.shadow}</h1>
              <p className="text-[8px] text-indigo-400/60 uppercase tracking-[0.3em] font-bold mt-0.5">{t.ai}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setActiveTab('settings')}
              className={`w-10 h-10 flex items-center justify-center rounded-full border border-white/5 transition-all ${activeTab === 'settings' ? 'bg-white text-black' : 'hover:bg-white/5 text-white/30'}`}
              title={t.settings}
            >
              <SettingsIcon size={18} />
            </button>
            <button 
              onClick={() => setIsMinimized(true)}
              className="w-10 h-10 flex items-center justify-center rounded-full border border-white/5 hover:bg-white/5 transition-all"
              title={language === 'ar' ? 'تصغير للخلفية' : 'Minimize to Background'}
            >
              <Minimize2 size={18} className="text-white/30" />
            </button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-8 overflow-y-auto pb-40">
          <AnimatePresence mode="wait">
            {activeTab === 'training' && (
              <motion.div 
                key="training"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-8 py-4"
              >
                <div className="relative">
                  <div className="w-24 h-24 rounded-full border border-white/5 flex items-center justify-center bg-white/[0.01] relative overflow-hidden group">
                    <PlusCircle className="text-indigo-400/20 w-10 h-10 group-hover:text-indigo-400 transition-all duration-500" />
                  </div>
                  <motion.div 
                    animate={{ scale: [1, 1.1, 1], opacity: [0.1, 0.2, 0.1] }}
                    transition={{ repeat: Infinity, duration: 4 }}
                    className="absolute inset-0 rounded-full border border-indigo-500/10"
                  />
                </div>
                <div className="space-y-3">
                  <h2 className="text-2xl font-light tracking-tight">{t.newSequence}</h2>
                  <p className="text-white/20 text-[11px] max-w-[220px] mx-auto leading-relaxed font-light">
                    {t.observationDesc}
                  </p>
                </div>
                <button 
                  onClick={startRecording}
                  className="w-full max-w-[280px] py-4 bg-white text-black text-[9px] font-bold uppercase tracking-[0.2em] rounded-full hover:bg-indigo-50 transition-all active:scale-[0.98]"
                >
                  {t.initiate}
                </button>
              </motion.div>
            )}

            {activeTab === 'tasks' && (
              <motion.div 
                key="tasks"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="space-y-10"
              >
                <div className="flex items-center justify-between border-b border-white/5 pb-6">
                  <h2 className="text-[9px] font-bold uppercase tracking-[0.2em] text-white/20">{t.activeSequences}</h2>
                  <span className="text-[9px] font-mono text-indigo-400/40">{tasks.length.toString().padStart(2, '0')}</span>
                </div>
                
                {tasks.length === 0 ? (
                  <div className="py-32 flex flex-col items-center justify-center text-center opacity-10">
                    <Ghost size={48} strokeWidth={0.5} className="mb-6" />
                    <p className="text-[9px] uppercase tracking-[0.2em] font-light">{t.emptyShadow}</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {tasks.map(task => (
                      <div key={task.id} className="group bg-white/[0.01] border border-white/5 p-5 rounded-2xl flex flex-col gap-4 hover:bg-white/[0.02] hover:border-white/10 transition-all duration-300">
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-4 min-w-0">
                            <div className="text-[8px] font-mono text-white/10 group-hover:text-indigo-400/30 transition-colors shrink-0">
                              {task.id.toString().slice(0, 2).toUpperCase()}
                            </div>
                            <div className="min-w-0">
                              <h3 className="text-base font-light tracking-wide group-hover:text-white transition-colors">{task.name}</h3>
                              <div className="flex items-center gap-3 mt-1">
                                <span className="text-[6px] font-medium text-white/20 uppercase tracking-[0.1em] shrink-0">{t.executions}: {task.actions.length}</span>
                                <div className="w-1 h-1 rounded-full bg-white/5 shrink-0"></div>
                                <span className="text-[6px] font-medium text-white/20 uppercase tracking-[0.1em] shrink-0">{new Date(task.createdAt).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-1.5 shrink-0">
                            <button 
                              onClick={() => {
                                const interval = prompt(language === 'ar' ? 'أدخل الفترة بالملي ثانية (مثلاً 60000 للدقيقة):' : 'Enter interval in ms (e.g. 60000 for 1 min):', '60000');
                                if (interval) scheduleTask(task.id, parseInt(interval));
                              }}
                              className={`w-8 h-8 rounded-full border border-white/5 flex items-center justify-center transition-all duration-300 ${task.schedule?.enabled ? 'text-indigo-400 border-indigo-500/30 bg-indigo-500/5' : 'text-white/20 hover:bg-white/5 hover:text-white'}`}
                              title={language === 'ar' ? 'جدولة المهمة' : 'Schedule Task'}
                            >
                              <Clock size={12} />
                            </button>
                            <button 
                              onClick={() => executeTask(task.id)} 
                              disabled={executingTaskId !== null}
                              className={`w-8 h-8 rounded-full border border-white/5 flex items-center justify-center transition-all duration-300 ${task.status === 'running' ? 'bg-indigo-500 text-white animate-pulse' : 'hover:bg-white hover:text-black'}`}
                            >
                              {task.status === 'running' ? <RefreshCw size={12} className="animate-spin" /> : <Play size={12} fill="currentColor" />}
                            </button>
                            <button 
                              onClick={() => {
                                const newName = prompt(language === 'ar' ? 'أدخل الاسم الجديد:' : 'Enter new name:', task.name);
                                if (newName) editTask(task.id, newName, task.description);
                              }}
                              className="w-8 h-8 rounded-full border border-white/5 text-white/20 flex items-center justify-center hover:bg-white/5 hover:text-white transition-all duration-300"
                              title={language === 'ar' ? 'تعديل المهمة' : 'Edit Task'}
                            >
                              <Edit3 size={12} />
                            </button>
                            <button 
                              onClick={() => deleteTask(task.id)} 
                              className="w-8 h-8 rounded-full border border-white/5 text-white/10 flex items-center justify-center hover:bg-red-500/10 hover:text-red-400 transition-all duration-300"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </div>
                        
                        {/* Progress Bar */}
                        {(task.status === 'running' || task.status === 'completed' || task.status === 'failed') && (
                          <div className="w-full space-y-2">
                            <div className="flex justify-between text-[8px] uppercase tracking-widest font-bold">
                              <span className={task.status === 'failed' ? 'text-red-400' : 'text-white/40'}>
                                {task.status === 'running' ? (language === 'ar' ? 'جاري التنفيذ...' : 'Executing...') : 
                                 task.status === 'completed' ? (language === 'ar' ? 'اكتمل بنجاح' : 'Completed') : 
                                 (language === 'ar' ? 'فشل التنفيذ' : 'Failed')}
                              </span>
                              <span className="text-white/60">{Math.round(task.progress)}%</span>
                            </div>
                            <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${task.progress}%` }}
                                className={`h-full ${task.status === 'failed' ? 'bg-red-500' : 'bg-indigo-500'}`}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
            {/* Settings Tab */}
            {activeTab === 'settings' && (
              <motion.div 
                key="settings"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="px-8 space-y-12 pb-32"
              >
                <div className="space-y-6">
                  <h2 className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/20 px-4">
                    {language === 'ar' ? 'إعدادات النظام' : 'System Settings'}
                  </h2>
                  <div className="bg-white/[0.02] border border-white/5 p-6 rounded-[2rem] space-y-8">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{language === 'ar' ? 'اللغة' : 'Language'}</span>
                      <button 
                        onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
                        className="text-[10px] uppercase font-bold tracking-widest bg-white/5 px-4 py-2 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        {language === 'ar' ? 'English' : 'العربية'}
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{language === 'ar' ? 'وضع المطور' : 'Developer Mode'}</span>
                      <div className="w-12 h-6 rounded-full bg-indigo-500/20 relative">
                        <div className="absolute top-1 right-1 w-4 h-4 bg-indigo-500 rounded-full" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Overlay Customization Section */}
                <div className="space-y-6">
                  <h2 className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/20 px-4">
                    {t.overlaySettings}
                  </h2>
                  <div className="bg-white/[0.02] border border-white/5 p-6 rounded-[2rem] space-y-6">
                    {/* Size Slider */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[11px] text-white/40 uppercase tracking-wider">{t.size}</span>
                        <span className="text-[11px] font-mono text-indigo-400">{overlayConfig.size}px</span>
                      </div>
                      <input 
                        type="range" min="40" max="100" 
                        value={overlayConfig.size}
                        onChange={(e) => setOverlayConfig({...overlayConfig, size: parseInt(e.target.value)})}
                        className="w-full h-1 bg-white/5 rounded-lg appearance-none cursor-pointer accent-indigo-400"
                      />
                    </div>

                    {/* Opacity Slider */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[11px] text-white/40 uppercase tracking-wider">{t.opacity}</span>
                        <span className="text-[11px] font-mono text-indigo-400">{Math.round(overlayConfig.opacity * 100)}%</span>
                      </div>
                      <input 
                        type="range" min="10" max="100" 
                        value={overlayConfig.opacity * 100}
                        onChange={(e) => setOverlayConfig({...overlayConfig, opacity: parseInt(e.target.value) / 100})}
                        className="w-full h-1 bg-white/5 rounded-lg appearance-none cursor-pointer accent-indigo-400"
                      />
                    </div>

                    {/* Shape Selection */}
                    <div className="flex justify-between items-center pt-2">
                      <span className="text-[11px] text-white/40 uppercase tracking-wider">{t.shape}</span>
                      <div className="flex gap-3">
                        {[
                          { id: 'circle', icon: Circle },
                          { id: 'rounded', icon: BoxSelect },
                          { id: 'square', icon: Square }
                        ].map(shape => (
                          <button 
                            key={shape.id}
                            onClick={() => setOverlayConfig({...overlayConfig, shape: shape.id as any})}
                            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${overlayConfig.shape === shape.id ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' : 'bg-white/5 text-white/20 border border-transparent'}`}
                          >
                            <shape.icon size={14} />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Color Selection */}
                    <div className="flex justify-between items-center pt-2">
                      <span className="text-[11px] text-white/40 uppercase tracking-wider">{t.color}</span>
                      <div className="flex gap-3">
                        {['#818cf8', '#f472b6', '#4ade80', '#fbbf24', '#ffffff'].map(color => (
                          <button 
                            key={color}
                            onClick={() => setOverlayConfig({...overlayConfig, color})}
                            className={`w-6 h-6 rounded-full border-2 transition-all ${overlayConfig.color === color ? 'border-indigo-400 scale-110' : 'border-transparent'}`}
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* System Status Section */}
                <div className="space-y-6">
                  <h2 className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/20 px-4">
                    {t.systemStatus}
                  </h2>
                  <div className="space-y-3">
                    {[
                      { id: 'accessibility', label: t.engine, status: permissions.accessibility ? t.active : (language === 'ar' ? 'غير نشط' : 'Inactive'), icon: Shield },
                      { id: 'overlay', label: t.overlay, status: permissions.overlay ? t.active : (language === 'ar' ? 'غير نشط' : 'Inactive'), icon: Layers },
                      { id: 'foreground', label: t.background, status: permissions.foreground ? t.running : (language === 'ar' ? 'متوقف' : 'Stopped'), icon: Activity }
                    ].map(item => (
                      <div 
                        key={item.label} 
                        onClick={() => togglePermission(item.id as any)}
                        className="bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex items-center justify-between group hover:border-indigo-500/20 transition-all cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${permissions[item.id as keyof typeof permissions] ? 'bg-indigo-500/10' : 'bg-white/[0.02]'}`}>
                            <item.icon size={14} className={permissions[item.id as keyof typeof permissions] ? 'text-indigo-400' : 'text-white/20'} />
                          </div>
                          <span className="text-sm font-light tracking-wide">{item.label}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`text-[8px] font-bold uppercase tracking-widest ${permissions[item.id as keyof typeof permissions] ? 'text-indigo-400' : 'text-white/20'}`}>
                            {item.status}
                          </span>
                          <div className="w-8 h-4 bg-white/5 rounded-full p-0.5 border border-white/5 relative flex items-center">
                            <motion.div 
                              animate={{ x: permissions[item.id as keyof typeof permissions] ? (language === 'ar' ? 0 : 16) : (language === 'ar' ? 16 : 0) }}
                              initial={false}
                              className={`w-3 h-3 rounded-full shadow-[0_0_4px_rgba(129,140,248,0.5)] ${permissions[item.id as keyof typeof permissions] ? 'bg-indigo-400' : 'bg-white/20'}`}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Version Info */}
                <div className="bg-white/[0.01] border border-white/5 p-5 rounded-2xl flex items-center justify-between opacity-40">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-white/[0.02] flex items-center justify-center">
                      <Info size={14} className="text-white/40" />
                    </div>
                    <span className="text-[11px] font-light tracking-wide">{t.version}</span>
                  </div>
                  <span className="text-[10px] font-mono tracking-tighter">{t.vNum}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Navigation Bar */}
        <nav className="fixed bottom-8 left-8 right-8 max-w-xl mx-auto bg-white/[0.01] backdrop-blur-3xl border border-white/5 p-2 rounded-full flex gap-2 z-50 shadow-2xl">
          {[
            { id: 'training', icon: PlusCircle, label: t.train },
            { id: 'tasks', icon: List, label: t.sequences }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-4 rounded-full flex items-center justify-center gap-3 transition-all duration-300 ${activeTab === tab.id ? 'bg-white text-black' : 'text-white/20 hover:text-white/40'}`}
            >
              <tab.icon size={18} />
              <span className="text-[10px] uppercase font-bold tracking-[0.15em]">{tab.label}</span>
            </button>
          ))}
        </nav>
      </motion.div>

      {/* 🟢 THE SHADOW OVERLAY (Only visible when minimized) */}
      <AnimatePresence>
        {isMinimized && (
          <motion.div 
            drag
            dragMomentum={false}
            dragConstraints={constraints}
            onDragStart={() => {
              if (dockTimerRef.current) clearTimeout(dockTimerRef.current);
              setIsDocked(false);
            }}
            onDragEnd={(e, info) => {
              const posX = info.point.x;
              const screenWidth = window.innerWidth;
              setButtonSide(posX < screenWidth / 2 ? 'left' : 'right');
              resetDockTimer();
            }}
            className="fixed z-[100] cursor-grab active:cursor-grabbing"
            style={{ 
              bottom: '160px', 
              right: '48px',
              touchAction: 'none',
              x,
              y
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: 1, 
              opacity: isDocked ? 0.3 : 1,
              filter: isDocked ? 'blur(2px)' : 'blur(0px)'
            }}
            exit={{ scale: 0, opacity: 0 }}
          >
            <div className="relative" onMouseEnter={resetDockTimer}>
              {/* Mini Menu */}
              <AnimatePresence>
                {showOverlayMenu && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9, x: buttonSide === 'left' ? -20 : 20 }}
                    animate={{ opacity: 1, scale: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.9, x: buttonSide === 'left' ? -20 : 20 }}
                    className={`absolute top-1/2 -translate-y-1/2 ${buttonSide === 'left' ? 'left-full ml-4' : 'right-full mr-4'} w-60 bg-black/90 backdrop-blur-3xl border border-white/10 p-4 rounded-[2rem] shadow-2xl overflow-hidden`}
                  >
                    <button 
                      onClick={startRecording}
                      className="w-full p-4 hover:bg-white hover:text-black text-white text-[10px] font-bold uppercase tracking-widest flex items-center gap-4 rounded-2xl transition-all"
                    >
                      <PlusCircle size={16} />
                      {t.newSequence}
                    </button>
                    <div className="h-px bg-white/5 my-4"></div>
                    <div className="px-2 space-y-2">
                      <p className="text-[7px] text-white/20 font-bold uppercase tracking-[0.4em] mb-3">{t.recent}</p>
                      {tasks.slice(0, 3).map(task => (
                        <button 
                          key={task.id}
                          onClick={() => executeTask(task.id)}
                          className="w-full p-3 hover:bg-white/5 text-[11px] font-light text-left flex items-center gap-4 rounded-xl transition-all"
                        >
                          <Play size={12} className="text-indigo-400" />
                          <span className="truncate">{task.name}</span>
                        </button>
                      ))}
                    </div>
                    <div className="h-px bg-white/5 my-4"></div>
                    <button 
                      onClick={() => setIsListening(!isListening)}
                      className="w-full p-4 hover:bg-white/5 text-white/40 text-[10px] font-bold uppercase tracking-widest flex items-center gap-4 rounded-2xl transition-all"
                    >
                      <Mic size={16} className={isListening ? 'text-indigo-400 animate-pulse' : ''} />
                      {t.voiceInput}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Main Floating Button */}
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setShowOverlayMenu(!showOverlayMenu);
                  resetDockTimer();
                }}
                style={{ 
                  width: overlayConfig.size, 
                  height: overlayConfig.size,
                  opacity: overlayConfig.opacity,
                  backgroundColor: isRecording ? '#ef4444' : 'black',
                  borderRadius: overlayConfig.shape === 'circle' ? '9999px' : overlayConfig.shape === 'square' ? '0px' : '16px'
                }}
                className={`flex items-center justify-center shadow-2xl transition-all border border-white/10 ${isRecording ? 'border-transparent shadow-red-500/20' : 'backdrop-blur-3xl shadow-white/5'}`}
              >
                {isRecording ? (
                  <StopCircle size={overlayConfig.size * 0.35} className="text-white" />
                ) : (
                  <Ghost size={overlayConfig.size * 0.35} style={{ color: overlayConfig.color }} />
                )}
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Recording HUD */}
      <AnimatePresence>
        {isRecording && isMinimized && (
          <motion.div 
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            exit={{ y: -100 }}
            className="fixed top-0 left-0 right-0 z-[110] bg-black/80 backdrop-blur-3xl p-8 border-b border-white/5 flex items-center justify-between"
          >
            <div className="flex items-center gap-6">
              <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.5)]"></div>
              <span className="text-[11px] font-bold uppercase tracking-[0.4em] text-white/40">{t.recording}</span>
            </div>
            <div className="flex gap-5">
              <button onClick={() => recordAction({ type: 'click', x: window.innerWidth / 2, y: window.innerHeight / 2 })} className="px-8 py-3 border border-white/5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-white/5 transition-all">{t.simulate}</button>
              <button onClick={stopRecording} className="px-8 py-3 bg-white text-black rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-50 transition-all">{t.finish}</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Save Task Modal */}
      <AnimatePresence>
        {showSaveModal && (
          <div className="fixed inset-0 bg-black/95 backdrop-blur-3xl z-[200] flex items-center justify-center p-12">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }} 
              animate={{ opacity: 1, scale: 1 }} 
              className="bg-black border border-white/5 p-12 rounded-[3rem] w-full max-w-md space-y-10 shadow-2xl"
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 rounded-full border border-white/5 flex items-center justify-center mx-auto bg-white/[0.01]">
                  <CheckCircle size={32} className="text-indigo-400" />
                </div>
                <h2 className="text-2xl font-light tracking-tight">{language === 'ar' ? 'تم التقاط المهمة' : 'Task Captured'}</h2>
              </div>
              
              <div className="space-y-4">
                <label className="text-[8px] font-bold uppercase tracking-[0.3em] text-white/10 px-3">{language === 'ar' ? 'اسم المهمة' : 'Task Name'}</label>
                <input 
                  type="text" 
                  placeholder={language === 'ar' ? 'مثال: فتح واتساب' : 'e.g. Open WhatsApp'} 
                  value={newTask.name} 
                  onChange={(e) => setNewTask({ ...newTask, name: e.target.value })} 
                  className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-[1.5rem] focus:outline-none focus:border-indigo-500/30 text-sm font-light transition-all placeholder:text-white/10" 
                />
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => {
                    setShowSaveModal(false);
                    setIsMinimized(false);
                  }} 
                  className="flex-1 py-5 rounded-full border border-white/5 text-white/20 text-[10px] font-bold uppercase tracking-widest hover:bg-white/5 transition-all"
                >
                  {language === 'ar' ? 'تجاهل' : 'Discard'}
                </button>
                <button 
                  onClick={saveTask} 
                  disabled={isSaving}
                  className={`flex-1 py-5 bg-white text-black rounded-full text-[10px] font-bold uppercase tracking-widest transition-all ${isSaving ? 'opacity-50 cursor-not-allowed' : 'hover:bg-indigo-50'}`}
                >
                  {isSaving ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (language === 'ar' ? 'تأكيد الحفظ' : 'Confirm Save')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Initial Setup Screen */}
      <AnimatePresence>
        {showSetup && (
          <div className="fixed inset-0 bg-black z-[300] flex flex-col items-center justify-center p-8 text-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-md space-y-10"
            >
              <div className="relative inline-block">
                <div className="w-24 h-24 rounded-[2.5rem] bg-indigo-600/20 flex items-center justify-center relative z-10">
                  <Shield className="text-indigo-400 w-10 h-10" />
                </div>
                <div className="absolute inset-0 bg-indigo-500/20 blur-3xl rounded-full -z-10 animate-pulse"></div>
              </div>

              <div className="space-y-4">
                <h2 className="text-3xl font-light tracking-tight">
                  {language === 'ar' ? 'مرحباً بك في Shadow' : 'Welcome to Shadow'}
                </h2>
                <p className="text-sm text-white/40 leading-relaxed font-light">
                  {language === 'ar' 
                    ? 'لكي يتمكن Shadow من التعلم والتحكم بدلاً منك، يحتاج إلى تفعيل "خدمة الوصول". هذه الصلاحية آمنة تماماً وتستخدم فقط لتنفيذ النقرات.'
                    : 'To allow Shadow to learn and execute tasks for you, it needs "Accessibility Service" enabled. This permission is safe and used only to perform clicks.'}
                </p>
              </div>

              <div className="space-y-4 pt-6">
                <button 
                  onClick={async () => {
                    await togglePermission('accessibility');
                    // In a real app, we'd wait for the user to return
                    // For simulation, we'll just let them proceed if they click it
                    if (Capacitor.getPlatform() !== 'android') {
                      setShowSetup(false);
                    }
                  }}
                  className="w-full py-5 rounded-full bg-white text-black font-bold uppercase tracking-[0.2em] text-[10px] shadow-[0_20px_40px_rgba(255,255,255,0.1)] hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  {language === 'ar' ? 'تفعيل خدمة الوصول' : 'Enable Accessibility'}
                </button>
                
                <button 
                  onClick={() => setShowSetup(false)}
                  className="text-[10px] text-white/20 uppercase tracking-widest font-bold hover:text-white/40 transition-all"
                >
                  {language === 'ar' ? 'تخطي الآن (لن يعمل التحكم التلقائي)' : 'Skip for now (Auto-control disabled)'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
