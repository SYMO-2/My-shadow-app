import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ParsedIntent {
  intent: string;
  target: string;
  action: string;
  confidence: number;
}

export async function parseCommand(command: string): Promise<ParsedIntent> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `حلل الأمر التالي باللغة العربية واستخرج النية (intent) والهدف (target) والإجراء (action). 
      الأمر: "${command}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            intent: { type: Type.STRING, description: "The core intent, e.g., send_message, open_app" },
            target: { type: Type.STRING, description: "The person or app targeted, e.g., Ahmed, WhatsApp" },
            action: { type: Type.STRING, description: "The specific action, e.g., send, write, call" },
            confidence: { type: Type.NUMBER, description: "Confidence score 0-1" }
          },
          required: ["intent", "target", "action", "confidence"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("NLP Error:", error);
    return {
      intent: "unknown",
      target: "none",
      action: "none",
      confidence: 0
    };
  }
}
